%Dissimilary%
%Normal%
p=0;
m=0;
(p-m)/p

%binary%
q=0;
r=0;
s=0;
t=0;

%Symetric%
(r+s)/(q+r+s+t)
%Assymetric%
(r+s)/(q+r+s)



%Numeric%
x=[];
y=[];
%Euclidean%
sqrt(sum((x-y).^2))
%Manhattan%
sum(abs(x-y))
%Supremum%



%Ordinal%
%1. Count states%
%2. Replace each data with ranks%
%3. Normalize%
ri=0;
m=0;
(r-1)/(m-1)
%Manhattan%
sum(abs(x-y))



x=[4.77 0.15 8.15 6.2 0.19 10.59]
sum(x)
x = [6 5 4 3 2 ]
y = [20 10 14 5 5]
n = length(x)

%sample mean of x
xBar = sum(x)/n

%sample mean of y
yBar = sum(y)/n


%correlation coefficient
%sx = sqrt(((sum(x.^2)- (sum(x)^2)/n))/(n))
%sy = sqrt(((sum(y.^2)- (sum(y)^2)/n))/(n))
%sec1 = (x-(sum(x)/n))/sx
%sec2 = (y-(sum(y)/n))/sy
%r = sum(sec1.*sec2)/(n)%


%correlation coefficient
sum((x-xBar).*(y-yBar))/n*sy*sx

%variance
sum((x-xBar).^2)/n
sum((y-yBar).^2)/n

%standard deviation
sx=sqrt(sum((x-xBar).^2)/n)
sy=sqrt(sum((y-yBar).^2)/n)

%Covariance of Numeric data
sum((x-xBar).*(y-yBar)/n)




%coeficient determination
r2 = r^2

%least square regression
ysquare = b1*x+b0
b1 = r*(sy/sx)
b0 = yBar - b1*xBar
corrcoef(x,y)



%minMAX norm
v=((x-min(x))/(max(x)-min(x)))*(1-0)+0


%zSore norm
z=(x-xBar)/sx


%decimal scaling
scale= 10;
x/scale





%CLASSIFICATIO
%information gain
pi=9/14;
infoD= -(sum(pi*log2(pi)))

infoAD=







4/10*log2(4/10)

7/10*(-4/7*log2(4/7)-3/7*log2(3/7))+3/10*(3/3*log2(3/3))

0.9710-0.6897


4/10*(-3/4*log2(3/4)-1/4*log2(1/4))+6/10*(-1/6*log2(1/6)-5/6*log2(5/6))

0.9710-0.7145


1-(4/10)^2-(6/10)^2




4/10*(1-(3/4)^2-(1/4)^2)+6/10*(1-(1/6)^2-(5/6)^2)









x=[2 -1 0 2 0 -3]
y = [-1 1 -1 0 0 -1]
sum(x.*y)
x.^2


