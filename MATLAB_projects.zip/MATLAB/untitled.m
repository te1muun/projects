x = [6 5 4 3 2 ]
y = [20 10 14 5 5]
n = length(x)

scatter(x,y)

%sample mean of x
xBar = sum(x)/n

%sample mean of y
yBar = sum(y)/n


%correlation coefficient
%sx = sqrt(((sum(x.^2)- (sum(x)^2)/n))/(n))
%sy = sqrt(((sum(y.^2)- (sum(y)^2)/n))/(n))
%sec1 = (x-(sum(x)/n))/sx
%sec2 = (y-(sum(y)/n))/sy
%r = sum(sec1.*sec2)/(n)


%correlation coefficient
sum((x-xBar).*(y-yBar))/n*sy*sx

%variance
sum((x-xBar).^2)/n
sum((y-yBar).^2)/n

%standard deviation
sx=sqrt(sum((x-xBar).^2)/n)
sy=sqrt(sum((y-yBar).^2)/n)

%Covariance of Numeric data
sum((x-xBar).*(y-yBar)/n)



%coeficient determination
r2 = r^2

%least square regression
ysquare = b1*x+b0
b1 = r*(sy/sx)
b0 = yBar - b1*xBar
corrcoef(x,y)



%minMAX norm
v=((x-min(x))/(max(x)-min(x)))*(1-0)+0


%zSore norm
z=(x-xBar)/sx


%decimal scaling
scale= 10;
x/scale









%CLASSIFICATIO
%information gain
pi=9/14;
infoD= -(sum(pi*log2(pi)))

infoAD=






