%% Chi Square

age = table2array(data(:,1))

gender= table2array(data(:,2))

class = table2array(data(:,end))

classCount = cdf("Normal",age,class)

h = kstest(age)

chi2gof(age)
zLogical = logical(gender)
z = chi2pdf(class, (length(class)-1))
male= count(A(:,1),"Male")
A = table2array(data(:,2:end))
strcmp(A(:,1),'Male')


%class
classCount = count(class,"Positive")
ySum = sum(classCount)
yMean = ySum/n

corrcoef(age, classCount)
corrcoef(age1,classCount)



%correlation coefficient
r = sum((age-ageMean).*(classCount-yMean))/n*sy*sx

%variance
sum((age-ageMean).^2)/n
sum((classCount-yMean).^2)/n

%standard deviation
sx=sqrt(sum((age-ageMean).^2)/n)
sy=sqrt(sum((classCount-yMean).^2)/n)



%Gender
gender= count(A(:,1),"Male")
maleSum= sum(male)
maleMean=maleSum/n






corrcoef(male, classCount)




%Polyuria
pol = count(A(:,2),"Yes")
polSum = sum(pol)
polMean = polSum/n



corrcoef(pol, classCount)


%Polydipsia
polydipsia = count(A(:,3),"Yes")
polydipsiaSum = sum(polydipsia)
polydipsiaMean = polydipsiaSum/n


corrcoef(polydipsia, classCount)




%SuddenWeightLoss
swl = count(A(:,4),"Yes")
swlSum = sum(swl)
swlMean = swlSum/n



corrcoef(swl, classCount)



%Weakness

weak =count(A(:,5),"Yes") 

corrcoef(weak, classCount)


%Polyphagia

polyphagia = count(A(:,6),"Yes") 
corrcoef(polyphagia, classCount)

%genital Thrust

gt=count(A(:,7),"Yes") 
corrcoef(gt, classCount)



%visual blurring
vb = count(A(:,8),"Yes") 
corrcoef(vb, classCount)



%itching
itch =  count(A(:,9),"Yes")
corrcoef(itch, classCount)


%Irritablity

irr = count(A(:,10),"Yes")
corrcoef(irr, classCount)






%delayed healing

dh = count(A(:,11),"Yes")
corrcoef(dh,classCount)


%partial paresis
pp = count(A(:,12),"Yes")
corrcoef(pp,classCount)


%mustle stiffness
ms =  count(A(:,13),"Yes")
corrcoef(ms,classCount)



%alopecia
alo = count(A(:,14),"Yes")
corrcoef(alo,classCount)


%obesity
obes = count(A(:,15),"Yes")
corrcoef(obes,classCount)





%% binary

tree = fitctree(dataFull, "class")
view(tree, "Mode", "graph")





