age = [23 23 27 27 39 41 47 49 50 52 54 54 56 57 58 58 60 61]
fat = [9.5 26.5 7.8 17.8 31.4 25.9 27.4 27.2 31.2 34.6 42.5 28.8 33.4 30.2 34.1 23.9 41.2 35.7]
length(fat)
mean(age)
mean(fat)
boxplot(age)
sortedFat = sort(fat)
median(age)
median(fat)
median(sortedFat)
S=std(sortedFat)
y1 = (sortedFat-mean(sortedFat)).^2
round(sum(x1),4,"decimals")
scatter(age, sortedFat)
scatter(age, fat)
qqplot(age,fat)
A1 = [1.5 2 1.6 1.2 1.5]
A2 = [1.7 1.9 1.8 1.5 1]

