A = table2array(Data(:,2:end))

%%all attributes and class vectors
age= table2array(Data(:,1))
class = (A(:,end) == 'Positive')
gender = (A(:,1) == 'Male')
polyuria = (A(:,2) == 'Yes')
polydipsia = (A(:,3) == 'Yes')
suddenWL = (A(:,4) == 'Yes')
weakness= (A(:,5) == 'Yes')
polyphagia= (A(:,6) == 'Yes')
genitalThrust= (A(:,7) == 'Yes')
visionB= (A(:,8) == 'Yes')
itching= (A(:,9) == 'Yes')
irritability = (A(:,10) == 'Yes')
delayedH= (A(:,11) == 'Yes')
partialParesis= (A(:,12) == 'Yes')
mustcleStiffness= (A(:,13) == 'Yes')
alopcia= (A(:,14) == 'Yes')
obesity= (A(:,15) == 'Yes')


%% Correlation of each one
corrcoef(age, class)
corrcoef(gender, class)
corrcoef(polyuria , class)
corrcoef(polydipsia , class)
corrcoef(suddenWL , class)
corrcoef(weakness , class)
corrcoef(polyphagia , class)
corrcoef(genitalThrust , class)
corrcoef(visionB , class)
corrcoef(itching , class)
corrcoef(irritability , class)
corrcoef(delayedH , class)
corrcoef(partialParesis , class)
corrcoef(mustleStiffness , class)
corrcoef(alopcia , class)
corrcoef(obesity , class)




%% binary three using data 
tree = fitctree(Data, "class")
view(tree, "Mode", "graph")



%% naive Bayesian

D1 = fitcnb(Data, 'class~Age+Gender+Polyuria+Polydipsia+suddenWeightLoss+weakness+Polyphagia+GenitalThrush+visualBlurring+Itching+Irritability+delayedHealing+partialParesis+muscleStiffness+Alopecia+Obesity')
x = predict(D1, Data)



cm = confusionchart(Data.class, x)
cm.RowSummary = 'row-normalized'
