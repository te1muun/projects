var str = "Rabbits are furry";
var position = str.search(/bits/);
if (position >= 0)
    document.write("'bits' appears in position ", position,
                   "<br />");
else
    document.write("'bits' does not appear in str <br />");
