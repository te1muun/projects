// rects.js
// This script illustrates the use of the rectangle methods of 
//  the canvas element to draw two rectangles.
    
function draw() {
  var dom = document.getElementById("myCanvas");
  if (dom.getContext) {
    var context = dom.getContext('2d');
    
// Draw the outer filled rectangle
    context.fillRect(100, 100, 200, 200);
    
// Clear a rectangle inside the first rectangle
    context.clearRect(150, 150, 100, 100);
    
// Draw a stroke rectangle inside the others
    context.strokeRect(180, 180, 40, 40);
    
// Draw a small filled rectangle in the center of the others
    context.fillRect(195, 195, 10, 10);
  }
}

draw();