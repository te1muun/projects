let ROWS = 9
let COLS = 9
let SIZE = 20
let BOMB = 10
let grid = document.getElementById('minefield')

let cells

let failedBombKey
let revealedKeys
let flaggedKeys
let map
let timer

function toKey(row, col) {
    return row + '-' + col
}

function fromKey(key) {
    return key.split('-').map(Number)
}

function createGrid() {
    grid.style.width = ROWS * SIZE + 'px'
    grid.style.height = COLS * SIZE + 'px'
    for (let i = 0; i < ROWS; i++) {
        for (let j = 0; j < COLS; j++) {
            let cell = document.createElement('button')
            cell.style.float = 'left'
            cell.style.width = SIZE + 'px'
            cell.style.height = SIZE + 'px'
            cell.oncontextmenu = (e) => { // 4. A right click must flag a tile or unflag a tile if already flagged.
                if (failedBombKey !== null) {
                    return
                }
                e.preventDefault()
                toggleFlag(key)
                updateButtons();
            }
            cell.onclick = (e) => { // 3. A left click must reveal a tile, if not flagged.
                if (failedBombKey !== null) {
                    return
                }
                if (flaggedKeys.has(key)) {
                    return
                }
                revealCell(key)
                updateButtons();
            }
            cell.onmousedown = (e) => {
                // 11. When a player is actively playing and the mouse is down: the smiley will be in limbo (face_limbo).
                if (failedBombKey !== null) {
                    return
                }
                if (flaggedKeys.has(key)) {
                    return
                }

                smiley.classList.add("face_limbo");
            }

            cell.onmouseup = (e) => {
                if (failedBombKey !== null) {
                    return
                }
                if (flaggedKeys.has(key)) {
                    return
                }

                smiley.classList.remove("face_limbo");
            }

            grid.appendChild(cell)
            let key = toKey(i, j)
            cells.set(key, cell)
        }
    }
}

function startGame() {
    failedBombKey = null
    revealedKeys = new Set()
    flaggedKeys = new Set()

    smiley.classList = ['smiley'];

    timeValue = 0;
    updateTimer();


    map = generateMap(generateBombs())
    if (cells) {
        updateButtons()
    } else {
        cells = new Map()
        createGrid()
    }
}

function updateButtons() {
    for (let i = 0; i < ROWS; i++) {
        for (let j = 0; j < COLS; j++) {
            let key = toKey(i, j)
            let cell = cells.get(key)

            cell.style.backgroundColor = ''
            cell.style.color = 'black'
            cell.classList = ['tile hidden'];
            cell.disabled = false

            let value = map.get(key)
            if (failedBombKey !== null && value === 'bomb') {
                cell.disabled = true

                if (key === failedBombKey) {
                    cell.classList.add(`mine_hit`);
                }
                else {
                    if (flaggedKeys.has(key))
                        cell.classList.add(`mine_marked`);
                    else
                        cell.classList.add(`mine`);
                }
            } else if (revealedKeys.has(key)) {
                // 7. A revealed tile will display a number indicating how many mines it is adjacent to
                cell.disabled = true

                cell.classList.add(`tile_${value}`);
            } else if (flaggedKeys.has(key)) {
                cell.classList.add(`flag`);
            }
        }
    }

    // check win state
    var smiley = document.getElementById("smiley");
    if (failedBombKey !== null) { // When a player reveals a mine, 
        showLoseStatus();

    } else {
        grid.style.pointerEvents = ''

        // check if non-mine is revealed
        if (revealedKeys.size >= ROWS * COLS - BOMB) {
            showWinStatus();

            return;
        }

        // check if non-mine is revealed
        if (revealedKeys.size + flaggedKeys.size > ROWS * COLS) {
            showLoseStatus();
        }
    }
}

function showLoseStatus() {
    grid.style.pointerEvents = 'none'
    smiley.classList.add("face_lose")

    setTimeout(function () {
        if (timer) {
            alert(`Sorry! You lose game`);
            window.clearInterval(timer);
        }
    }, 100);
}

function showWinStatus() {
    smiley.classList.add("face_win");
    setTimeout(function () {
        if (timer) {
            alert(`Contratulation! You won game. Completion Time: ${timeValue} s`);
            window.clearInterval(timer);
        }
    }, 100);
}

function toggleFlag(key) {
    if (flaggedKeys.has(key)) {
        flaggedKeys.delete(key)
    } else {
        flaggedKeys.add(key)
    }
}

function revealCell(key) {
    if (map.get(key) === 'bomb') {
        if (revealedKeys.size < 1) // 9. In this assignment the first tile clicked must not be a mine
        {
            let finded_key = '';
            // find one key wich is not revealed
            for (let i = 0; i < ROWS; i++) {
                if (finded_key != '')
                    break;
                for (let j = 0; j < COLS; j++) {
                    key = toKey(i, j);
                    if (map.get(key) !== 'bomb') {
                        finded_key = key;
                        break;
                    }
                }
            }

            key = finded_key;
        }
    }

    if (map.get(key) === 'bomb') {
        failedBombKey = key
    } else {
        // 10. A timer will keep track of the how long the user has been playing. It begins ticking once the first tile is revealed.
        startTimer();

        // 8. If a tile is revealed and is not adjacent to any mines , it will reveal all adjacent tiles. This
        // includes adjacent tiles with numbers on them.
        propagateReveal(key, new Set())
    }
}

function propagateReveal(key, visited) {
    if (!flaggedKeys.has(key)) // A tile will not be revealed by any means (middle click or left click) if the tile is flagged.
        revealedKeys.add(key)

    visited.add(key)

    let isEmpty = !map.has(key)
    if (isEmpty) {
        for (let neighborKey of getNeighbors(key)) {
            if (!visited.has(neighborKey)) {
                propagateReveal(neighborKey, visited)
            }
        }
    }
}

function isInBounds([row, col]) {
    if (row < 0 || col < 0) {
        return false
    }
    if (row >= ROWS || col >= COLS) {
        return false
    }
    return true
}

function getNeighbors(key) {
    let [row, col] = fromKey(key)

    // 2. Adjacent is defined by the 8 tiles surrounding the target tile, on the diagonal, horizontal,
    // and vertical planes.

    let neighborRowCols = [
        [row - 1, col - 1],
        [row - 1, col],
        [row - 1, col + 1],
        [row, col - 1],
        [row, col + 1],
        [row + 1, col - 1],
        [row + 1, col],
        [row + 1, col + 1],
    ]
    return neighborRowCols
        .filter(isInBounds)
        .map(([r, c]) => toKey(r, c))
}

function generateBombs() {
    let count = BOMB
    let allKeys = []
    for (let i = 0; i < ROWS; i++) {
        for (let j = 0; j < COLS; j++) {
            allKeys.push(toKey(i, j))
        }
    }
    allKeys.sort(() => {
        let coinFlip = Math.random() > 0.5
        return coinFlip ? 1 : -1
    })
    return allKeys.slice(0, count)
}

function generateMap(seedBombs) {
    let map = new Map()

    function incrementDanger(neighborKey) {
        if (!map.has(neighborKey)) {
            map.set(neighborKey, 1);
        } else {
            let oldVal = map.get(neighborKey)
            if (oldVal !== 'bomb') {
                map.set(neighborKey, oldVal + 1)
            }
        }
    }
    for (let key of seedBombs) {
        map.set(key, 'bomb');
        for (let neighborKey of getNeighbors(key)) {
            incrementDanger(neighborKey)
        }
    }
    return map
}


function setDifficulty() {
    // 1. Users must be able to choose from three difficulties: Easy, Medium, and Hard.
    var difficultySelector = document.getElementById("difficulty");
    var difficulty = difficultySelector.selectedIndex;
    if (difficulty == 0) {
        BOMB = 9;
        COLS = 9;
        ROWS = 10;
    }
    if (difficulty == 1) {
        BOMB = 40;
        COLS = 16;
        ROWS = 16;
    }
    if (difficulty == 2) {
        BOMB = 99;
        COLS = 30;
        ROWS = 16;
    }

    cells = undefined;
    grid.innerHTML = '';

    startGame();
}




function smileyDown() {
    var smiley = document.getElementById("smiley");
    smiley.classList.add("face_down");
}

function smileyUp() {
    var smiley = document.getElementById("smiley");
    smiley.classList.remove("face_down");
}

function smileyLimbo() {
    var smiley = document.getElementById("smiley");
    smiley.classList.add("face_limbo")
}

function startTimer() {
    if (timer)
        return;

    timeValue = 0;
    timer = window.setInterval(onTimerTick, 1000);
}

// 10. A timer will keep track of the how long the user has been playing
function onTimerTick() {
    timeValue++;
    updateTimer();
}

function updateTimer() {
    document.getElementById("timer").innerHTML = timeValue;
}
setDifficulty()