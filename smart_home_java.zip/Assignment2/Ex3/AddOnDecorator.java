package ex3;


public abstract class AddOnDecorator extends OurFurnace {
	protected OurFurnace myFurnace;
}
