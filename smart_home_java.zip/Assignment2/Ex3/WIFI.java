package ex3;


public class WIFI extends AddOnDecorator {
	
		public WIFI(OurFurnace myFurnace) {
			super.myFurnace = myFurnace;
		}
		
		public String turnOn() {
			return(myFurnace.turnOn().concat("Wifi: Initialized"));
		}
	}
