package itec3030.assignments.a2;

import itec3030.smarthome.standards.ControllerInterface;
import itec3030.smarthome.standards.TemperatureSensor;
import newtemp.NewTempSensor.NewTempSensorDriver;
import newtemp.NewTempSensor.Observer;

public class NewTempSensorAdapter implements AbstractNewTempSensorAdapter, TemperatureSensor, Observer {
	
	//Attributes 
	private NewTempSensorDriver sensorDriver;
	private String name;
	private int temperature;
	private boolean enable;
	private ControllerInterface controlthermostat;

	
	//Class constructor 
	public NewTempSensorAdapter() {
		sensorDriver = new NewTempSensorDriver();
	}
	
	
	@Override
	public NewTempSensorDriver getAdatptee() {
		//returns the adaptee of the adapter 
		return this.sensorDriver;
	}
	
	@Override
	public void enable() {
		//set enable to true
		this.enable =true;
	}
	
	@Override
	public void disable() {
		//set enable to false
		this.enable = false;
	}
	
	@Override
	public boolean enabled() {
		//return value for enable
		return this.enable;
	}
	
	@Override
	public void setID(String ID) {
		//update name value 
		this.name = ID;
	}
	
	public String getID() {
		//return name value
		return this.name;
	}
	
	@Override 
	public int getReading() {
		//returns temperature
		return this.temperature;
	}

	@Override
	 public ControllerInterface getController(){
	 return this.controlthermostat;
	 }

	@Override
	 public void setController(ControllerInterface contollerInterface){
	 this.controlthermostat=contollerInterface;
	 }
	
	@Override
	public void newTemperature (int temperature) {
		//sets new temperature 
		this.temperature=temperature;
		//prints new message 
		System.out.println("Sensor (" + this.name + ") receiving new temperature: " + this.getReading());
	}
	
	@Override
	public void update(int temperature) {
		//updates temperature
		this.temperature=temperature;
		//prints updated message
		System.out.println("Sensor (" + this.name + ") receiving new temperature: " + this.getReading());
	}






}
