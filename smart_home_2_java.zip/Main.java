package ex3;

public class Main {

    public static void main(String[] args) throws InterruptedException {

        
        
        OurFurnace n = new PlainGasF1();
        n = new Humidifier(n);
        n = new WIFI(n);
        n.turnOn();
        System.out.println(n.turnOn());
    }
}