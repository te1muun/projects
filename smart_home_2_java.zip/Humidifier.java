package ex3;


public class Humidifier extends AddOnDecorator {
	public Humidifier(OurFurnace myFurnace) {
		super.myFurnace = myFurnace;
	}
	
	public String turnOn() {
		return(myFurnace.turnOn().concat("Humidifier: On"));
	}
}

