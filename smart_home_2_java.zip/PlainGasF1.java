package ex3;


public class PlainGasF1 extends OurFurnace {

	public String turnOn() {
		return("PlainGasF1: Up and Running");

	}

}

