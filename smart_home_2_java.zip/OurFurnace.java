package ex3;


public abstract class OurFurnace {
	public abstract String turnOn() ;
}


